# THE OMEN ONLINE v1.0

Web game full-stack cho The Omen: đăng nhập/đăng ký, tạo/tham gia phòng, WebSocket realtime, 3 phe, thư viện chức nghiệp, phân vai, ngày/đêm, kỹ năng, hiệu ứng, nhật ký và điều khiển Quản trò.

## Chạy trên máy

Yêu cầu Node.js 20+.

```bash
npm install
npm start
```

Mở: http://localhost:3000

## Cấu trúc

- `server.js` — backend Express + WebSocket
- `public/index.html` — ứng dụng online chính
- `public/quickstart.html` — bản offline thử nhanh
- `package.json` — dependency và lệnh chạy
- `render.yaml` — cấu hình deploy Render

## Deploy Render

1. Đưa toàn bộ thư mục này lên GitHub.
2. Trong Render chọn New → Blueprint và chọn repository.
3. Render đọc `render.yaml`, cài dependency và chạy `npm start`.
4. Sau khi deploy, mở URL `.onrender.com` được cấp cho service.

Bản Free phù hợp thử nghiệm. Filesystem Free là tạm thời, vì vậy dữ liệu JSON của người dùng/phòng có thể mất khi service restart/redeploy. Nếu cần dữ liệu bền vững cho sử dụng lâu dài, chuyển storage sang Postgres hoặc dùng compute có persistent disk.
