import express from 'express';
import { createServer } from 'node:http';
import { WebSocketServer } from 'ws';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'storage');
const DATA_FILE = path.join(DATA_DIR, 'data.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

const seedRoles = [
  {id:'human-basic',name:'Dân thường',faction:'Người',unlimited:true,pct:0,max:null,timing:'Không có kỹ năng',uses:null,description:'Vai nền phe Người. Không có kỹ năng chủ động.',effect:'Không có.',winCondition:'Phe Người đạt điều kiện thắng của ván.',enabled:true},
  {id:'demon-basic',name:'Quỷ thường',faction:'Quỷ',unlimited:true,pct:0,max:null,timing:'Ban đêm',uses:null,description:'Vai nền phe Quỷ. Hành động chung của phe Quỷ do Quản trò cấu hình.',effect:'Theo luật phe Quỷ của ván.',winCondition:'Phe Quỷ đạt điều kiện thắng của ván.',enabled:true},
  {id:'demon-hunter',name:'Thợ săn quỷ',faction:'Người',unlimited:false,pct:0,max:1,timing:'Mỗi 2 đêm',uses:null,description:'Chọn người nghi ngờ là Quỷ để đặt Dấu Ấn. Cấu hình chi tiết Dấu Ấn có thể chỉnh trong Kho.',effect:'Dấu Ấn theo cấu hình của ván; có thể khóa kỹ năng, lây truyền hoặc xử lý vào mốc đã định.',winCondition:'Theo điều kiện thắng phe Người.',enabled:true},
  {id:'high-priestess',name:'Nữ tư tế',faction:'Người',unlimited:false,pct:0,max:1,timing:'Ban đêm',uses:null,description:'Kỹ năng Yes/No theo câu hỏi hoặc mục tiêu do Quản trò quy định.',effect:'Kết quả được ghi vào nhật ký ván.',winCondition:'Theo điều kiện thắng phe Người.',enabled:true},
  {id:'pope',name:'Giáo Hoàng',faction:'Người',unlimited:false,pct:0,max:1,timing:'Ban đêm',uses:null,description:'Bảo vệ một mục tiêu theo luật ván.',effect:'Tạo hiệu ứng bảo vệ trong thời hạn cấu hình.',winCondition:'Theo điều kiện thắng phe Người.',enabled:true},
  {id:'medium',name:'Bà đồng',faction:'Người',unlimited:false,pct:0,max:1,timing:'Ban đêm',uses:null,description:'Tương tác với thông tin liên quan người đã chết theo luật ván.',effect:'Kết quả được ghi vào nhật ký.',winCondition:'Theo điều kiện thắng phe Người.',enabled:true},
  {id:'alchemist',name:'Dược sư',faction:'Người',unlimited:false,pct:0,max:1,timing:'Ban đêm',uses:2,description:'Sử dụng dược phẩm theo số lượt và điều kiện do Quản trò cấu hình.',effect:'Có thể tạo bảo vệ hoặc tác động theo cấu hình.',winCondition:'Theo điều kiện thắng phe Người.',enabled:true},
  {id:'death',name:'Death',faction:'Độc lập',unlimited:false,pct:0,max:1,timing:'Theo luật riêng',uses:null,description:'Chức nghiệp Độc lập. Điều kiện thắng phải được cấu hình rõ trong Kho trước khi dùng.',effect:'Theo luật riêng của chức nghiệp.',winCondition:'Được Quản trò cấu hình; không dùng điều kiện mặc định.',enabled:true},
  {id:'beelzebub',name:'Beelzebub',faction:'Quỷ',unlimited:false,pct:0,max:1,timing:'Ban đêm',uses:2,description:'Dịch Ruồi: đặt hiệu ứng lây nhiễm lên mục tiêu theo luật đã thống nhất; chức nghiệp có 2 lượt trong một ván.',effect:'Mục tiêu bị nhiễm có thể mất chức năng vào đêm tiếp theo và có thể lây theo cấu hình hiệu ứng.',winCondition:'Theo điều kiện thắng phe Quỷ.',enabled:true},
  {id:'valac',name:'Valac',faction:'Quỷ',unlimited:false,pct:0,max:1,timing:'Ban đêm',uses:null,description:'Vết Cắn Ảo Giác: đưa mục tiêu vào trạng thái Ảo Giác. Nếu điều kiện sống sót của Valac không bị phá trong 3 đêm, mục tiêu có thể chuyển phe theo luật ván.',effect:'Ảo Giác có thời hạn/điều kiện được ghi trong hiệu ứng.',winCondition:'Theo điều kiện thắng phe Quỷ.',enabled:true},
  {id:'dantalion',name:'Dantalion',faction:'Quỷ',unlimited:false,pct:0,max:1,timing:'Ban đêm',uses:null,description:'Có thể sao chép hiệu ứng của một người chơi khác, không sao chép chức nghiệp hiếm nếu luật ván cấm.',effect:'Tạo bản sao hiệu ứng theo mục tiêu.',winCondition:'Theo điều kiện thắng phe Quỷ.',enabled:true},
  {id:'sabnock',name:'Sabnock',faction:'Quỷ',unlimited:false,pct:0,max:1,timing:'Thụ động',uses:null,description:'Có 2 lớp sinh mệnh theo luật hiện tại của The Omen.',effect:'Lớp sinh mệnh thứ hai được theo dõi riêng.',winCondition:'Theo điều kiện thắng phe Quỷ.',enabled:true},
  {id:'lucy',name:'Thánh Lucy',faction:'Người',unlimited:false,pct:0,max:1,timing:'Thụ động / ban đêm',uses:null,description:'Miễn nhiễm với lời nguyền và có thể kiểm tra một người có hiệu ứng tiêu cực theo luật ván.',effect:'Miễn nhiễm/kiểm tra theo cấu hình.',winCondition:'Theo điều kiện thắng phe Người.',enabled:true}
];

let db = {version:1,users:[],roles:seedRoles,rooms:{}};
try { if (fs.existsSync(DATA_FILE)) db = {...db, ...JSON.parse(fs.readFileSync(DATA_FILE,'utf8'))}; } catch { /* start fresh */ }
if (!Array.isArray(db.roles) || !db.roles.length) db.roles = seedRoles;
const write = () => { const tmp = DATA_FILE+'.tmp'; fs.writeFileSync(tmp, JSON.stringify(db,null,2)); fs.renameSync(tmp, DATA_FILE); };

const sessions = new Map();
const sockets = new Map();
const now = () => new Date().toISOString();
const id = (prefix='id') => prefix+'_'+crypto.randomBytes(9).toString('base64url');
const roomCode = () => { let c; do c=crypto.randomBytes(3).toString('hex').toUpperCase(); while(db.rooms[c]); return c; };
const hashPassword = password => crypto.scryptSync(password, process.env.PASSWORD_PEPPER || 'the-omen-local-pepper', 64).toString('hex');
const token = () => crypto.randomBytes(32).toString('base64url');
function auth(req){ const t=(req.headers.authorization||'').replace(/^Bearer\s+/i,''); const s=sessions.get(t); if(!s) return null; if(s.expires<Date.now()){sessions.delete(t);return null;} return s.userId; }
function requireAuth(req,res){ const uid=auth(req); if(!uid) res.status(401).json({error:'Bạn chưa đăng nhập.'}); return uid; }
function getRoom(code){return db.rooms[String(code||'').toUpperCase()]||null;}
function getMember(room,uid){return room.players.find(p=>p.userId===uid)||null;}
function event(room,type,detail,extra={}){room.events.unshift({id:id('evt'),time:now(),phase:phaseLabel(room),type,detail,...extra});room.events=room.events.slice(0,500);}
function phaseLabel(room){return `${room.phase} ${room.phase==='Đêm'?room.night:room.day}`;}
function sanitizeRoom(room,uid){
  const me=getMember(room,uid); const gm=room.hostId===uid;
  return {code:room.code,name:room.name,hostId:room.hostId,started:room.started,ended:room.ended,phase:room.phase,night:room.night,day:room.day,maxNights:room.config.maxNights,config:gm?room.config:{name:room.config.name},
    players:room.players.map(p=>({id:p.id,userId:p.userId,name:p.name,status:p.status,cause:p.cause||'',faction:(gm||p.userId===uid)?p.faction:'ẨN',role:(gm||p.userId===uid)?p.role:'ẨN',effects:(gm||p.userId===uid)?p.effects:[],uses:(gm||p.userId===uid)?p.uses:{}})),
    effects:room.effects.map(e=>({...e,hiddenTarget:!gm&&e.targetUserId!==uid})),
    events:gm?room.events:room.events.filter(e=>e.public!==false || e.actorUserId===uid || e.targetUserId===uid).slice(0,100),
    professionLibrary:gm?db.roles.filter(r=>r.enabled):[]
  };
}
function broadcastRoom(code){const room=getRoom(code);if(!room)return; for(const ws of sockets.get(code)||[]) { if(ws.readyState===1) ws.send(JSON.stringify({type:'room_state',data:sanitizeRoom(room,ws.userId)})); }}
function checkWin(room){
  if(!room.started||room.ended)return null;
  const alive=room.players.filter(p=>p.status==='Sống');
  const factions={'Người':alive.filter(p=>p.faction==='Người').length,'Quỷ':alive.filter(p=>p.faction==='Quỷ').length,'Độc lập':alive.filter(p=>p.faction==='Độc lập').length};
  // Do not invent a generic independent victory condition. Only custom room conditions may resolve automatically.
  let winner=null;
  if(room.config.winMode==='human_demon' && factions.Quỷ===0 && factions.Người>0) winner='Người';
  if(room.config.winMode==='human_demon' && factions.Người===0 && factions.Quỷ>0) winner='Quỷ';
  if(winner){room.ended=true;room.winner=winner;event(room,'Kết thúc ván',`Phe ${winner} đạt điều kiện thắng.`,{public:true});return winner;}
  return null;
}

const app=express(); const http=createServer(app); const wss=new WebSocketServer({server:http,path:'/ws'});
app.use(express.json({limit:'1mb'}));
app.get('/health',(req,res)=>res.json({ok:true,service:'the-omen-online',version:'0.9.0'}));
app.get('/api/meta',(req,res)=>res.json({name:'The Omen',version:'0.9.0',factions:['Người','Quỷ','Độc lập']}));

app.post('/api/auth/register',(req,res)=>{
  const email=String(req.body?.email||'').trim().toLowerCase(), password=String(req.body?.password||''), name=String(req.body?.name||'').trim()||email.split('@')[0];
  if(!/^\S+@\S+\.\S+$/.test(email))return res.status(400).json({error:'Email không hợp lệ.'});
  if(password.length<6)return res.status(400).json({error:'Mật khẩu phải có ít nhất 6 ký tự.'});
  if(db.users.some(u=>u.email===email))return res.status(409).json({error:'Email này đã được đăng ký.'});
  const u={id:id('usr'),email,name,passwordHash:hashPassword(password),createdAt:now()};db.users.push(u);write();
  const t=token();sessions.set(t,{userId:u.id,expires:Date.now()+30*864e5});res.json({token:t,user:{id:u.id,email:u.email,name:u.name}});
});
app.post('/api/auth/login',(req,res)=>{
  const email=String(req.body?.email||'').trim().toLowerCase(), password=String(req.body?.password||''); const u=db.users.find(x=>x.email===email);
  if(!u||!crypto.timingSafeEqual(Buffer.from(u.passwordHash,'hex'),Buffer.from(hashPassword(password),'hex')))return res.status(401).json({error:'Email hoặc mật khẩu không đúng.'});
  const t=token();sessions.set(t,{userId:u.id,expires:Date.now()+30*864e5});res.json({token:t,user:{id:u.id,email:u.email,name:u.name}});
});
app.get('/api/auth/me',(req,res)=>{const uid=auth(req);if(!uid)return res.status(401).json({error:'Chưa đăng nhập.'});const u=db.users.find(x=>x.id===uid);res.json({user:{id:u.id,email:u.email,name:u.name}})});
app.post('/api/auth/logout',(req,res)=>{const t=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');sessions.delete(t);res.json({ok:true})});

app.get('/api/roles',(req,res)=>{const uid=requireAuth(req,res);if(!uid)return;res.json({roles:db.roles})});
app.post('/api/roles',(req,res)=>{const uid=requireAuth(req,res);if(!uid)return;const u=db.users.find(x=>x.id===uid);if(!u)return res.status(401).end();const r=req.body||{};if(!String(r.name||'').trim())return res.status(400).json({error:'Thiếu tên chức nghiệp.'});const role={id:r.id||id('role'),name:String(r.name).trim(),faction:['Người','Quỷ','Độc lập'].includes(r.faction)?r.faction:'Người',unlimited:!!r.unlimited,pct:Number(r.pct||0),max:r.max===''||r.max==null?null:Number(r.max),timing:String(r.timing||''),uses:r.uses===''||r.uses==null?null:Number(r.uses),description:String(r.description||''),effect:String(r.effect||''),winCondition:String(r.winCondition||''),enabled:r.enabled!==false};const i=db.roles.findIndex(x=>x.id===role.id);if(i>=0)db.roles[i]=role;else db.roles.push(role);write();res.json({role})});
app.delete('/api/roles/:id',(req,res)=>{const uid=requireAuth(req,res);if(!uid)return;db.roles=db.roles.filter(r=>r.id!==req.params.id);write();res.json({ok:true})});

app.post('/api/rooms',(req,res)=>{const uid=requireAuth(req,res);if(!uid)return;const u=db.users.find(x=>x.id===uid);const code=roomCode();const r={code,name:String(req.body?.name||'The Omen').trim(),hostId:uid,started:false,ended:false,phase:'Đêm',night:0,day:0,winner:null,config:{name:String(req.body?.name||'The Omen').trim(),maxNights:Number(req.body?.maxNights||20),humanPct:null,demonPct:null,independentPct:null,roles:[],winMode:'manual'},players:[{id:id('plr'),userId:uid,name:u.name,faction:'GM',role:'Quản trò',status:'Sống',cause:'',effects:[],uses:{}}],effects:[],events:[]};event(r,'Tạo phòng','Phòng được tạo.',{public:true});db.rooms[code]=r;write();res.json({room:sanitizeRoom(r,uid)})});
app.get('/api/rooms/:code',(req,res)=>{const uid=requireAuth(req,res);if(!uid)return;const r=getRoom(req.params.code);if(!r)return res.status(404).json({error:'Không tìm thấy phòng.'});if(!getMember(r,uid))return res.status(403).json({error:'Bạn chưa tham gia phòng.'});res.json({room:sanitizeRoom(r,uid)})});
app.post('/api/rooms/:code/join',(req,res)=>{const uid=requireAuth(req,res);if(!uid)return;const r=getRoom(req.params.code);if(!r)return res.status(404).json({error:'Không tìm thấy phòng.'});if(r.started)return res.status(409).json({error:'Ván đã bắt đầu, không thể tham gia.'});if(!getMember(r,uid)){const u=db.users.find(x=>x.id===uid);r.players.push({id:id('plr'),userId:uid,name:String(req.body?.name||u.name).trim()||u.name,faction:'Chưa phân phe',role:'Chưa phân vai',status:'Sống',cause:'',effects:[],uses:{}});event(r,'Người chơi tham gia',`${u.name} đã vào phòng.`,{public:true});write();broadcastRoom(r.code);}res.json({room:sanitizeRoom(r,uid)})});
app.post('/api/rooms/:code/leave',(req,res)=>{const uid=requireAuth(req,res);if(!uid)return;const r=getRoom(req.params.code);if(!r)return res.status(404).json({error:'Không tìm thấy phòng.'});if(r.hostId===uid)return res.status(400).json({error:'Quản trò không thể rời phòng. Hãy kết thúc/xóa phòng.'});r.players=r.players.filter(p=>p.userId!==uid);event(r,'Người chơi rời phòng','Một người chơi đã rời phòng.',{public:true});write();broadcastRoom(r.code);res.json({ok:true})});

app.post('/api/rooms/:code/config',(req,res)=>{const uid=requireAuth(req,res);if(!uid)return;const r=getRoom(req.params.code);if(!r)return res.status(404).json({error:'Không tìm thấy phòng.'});if(r.hostId!==uid)return res.status(403).json({error:'Chỉ quản trò được cấu hình.'});if(r.started)return res.status(409).json({error:'Ván đã bắt đầu.'});const c=req.body||{};const h=Number(c.humanPct),d=Number(c.demonPct),i=Number(c.independentPct);if([h,d,i].some(x=>Number.isNaN(x))||Math.abs(h+d+i-100)>0.001)return res.status(400).json({error:'Người + Quỷ + Độc lập phải bằng 100%.'});r.config={...r.config,name:String(c.name||r.name),maxNights:Math.max(1,Number(c.maxNights||20)),humanPct:h,demonPct:d,independentPct:i,roles:Array.isArray(c.roles)?c.roles:[],winMode:c.winMode==='human_demon'?'human_demon':'manual'};event(r,'Cấu hình ván','Quản trò cập nhật cấu hình.',{public:false});write();broadcastRoom(r.code);res.json({room:sanitizeRoom(r,uid)})});

function assignRoles(r){
  const weights=[['Người',r.config.humanPct],['Quỷ',r.config.demonPct],['Độc lập',r.config.independentPct]]; const nonHost=r.players.filter(p=>p.userId!==r.hostId); if(!nonHost.length)throw Error('Cần ít nhất 1 người chơi ngoài Quản trò.');
  for(const p of nonHost){let roll=Math.random()*100,acc=0;p.faction='Độc lập';for(const [f,w] of weights){acc+=w;if(roll<acc){p.faction=f;break}}p.role=p.faction==='Người'?'Dân thường':p.faction==='Quỷ'?'Quỷ thường':'Chưa cấu hình Độc lập';p.uses={};p.effects=[];p.status='Sống';p.cause='';}
  const selected=r.config.roles.map(x=>db.roles.find(z=>z.id===x.id)).filter(Boolean);
  for(const faction of ['Người','Quỷ','Độc lập']){
    const group=nonHost.filter(p=>p.faction===faction), pool=selected.filter(x=>x.faction===faction&&x.enabled&&x.name!== (faction==='Người'?'Dân thường':faction==='Quỷ'?'Quỷ thường':'__none__'));
    if(faction==='Độc lập' && group.length && pool.reduce((s,x)=>s+Math.max(0,Number(x.pct)||0),0)<=0) throw Error('Có người được phân vào phe Độc lập nhưng chưa chọn chức nghiệp Độc lập có tỷ lệ > 0%.');
    for(const p of group){const available=pool.filter(role=>role.max==null||group.filter(x=>x.role===role.name).length<role.max);const total=available.reduce((s,x)=>s+Math.max(0,Number(x.pct)||0),0);if(total<=0)continue;let roll=Math.random()*total,acc=0;for(const role of available){acc+=Number(role.pct)||0;if(roll<acc){p.role=role.name;p.roleSnapshot=JSON.parse(JSON.stringify(role));if(role.uses!=null)p.uses[role.id]=role.uses;break;}}}
  }
}
app.post('/api/rooms/:code/start',(req,res)=>{const uid=requireAuth(req,res);if(!uid)return;const r=getRoom(req.params.code);if(!r)return res.status(404).json({error:'Không tìm thấy phòng.'});if(r.hostId!==uid)return res.status(403).json({error:'Chỉ quản trò được bắt đầu.'});if(r.players.filter(p=>p.userId!==uid).length<1)return res.status(400).json({error:'Cần ít nhất 1 người chơi.'});try{assignRoles(r)}catch(e){return res.status(400).json({error:e.message})}r.started=true;r.ended=false;r.phase='Đêm';r.night=1;r.day=1;r.effects=[];event(r,'Bắt đầu ván','Vai đã được phân và khóa theo snapshot của ván.',{public:false});write();broadcastRoom(r.code);res.json({room:sanitizeRoom(r,uid)})});

app.post('/api/rooms/:code/phase',(req,res)=>{const uid=requireAuth(req,res);if(!uid)return;const r=getRoom(req.params.code);if(!r)return res.status(404).json({error:'Không tìm thấy phòng.'});if(r.hostId!==uid)return res.status(403).json({error:'Chỉ quản trò được chuyển pha.'});if(!r.started||r.ended)return res.status(400).json({error:'Ván chưa chạy hoặc đã kết thúc.'});const dir=Number(req.body?.direction||1);if(dir!==1&&dir!==-1)return res.status(400).json({error:'Direction không hợp lệ.'});if(dir===1){for(const e of r.effects){if(e.status==='ACTIVE'){e.remaining=Math.max(0,e.remaining-1);if(e.remaining===0)e.status='EXPIRED';}}if(r.phase==='Đêm'){r.phase='Ngày';r.day=r.night;}else{if(r.night>=r.config.maxNights){event(r,'Đạt giới hạn đêm',`Đã đến đêm tối đa ${r.config.maxNights}.`,{public:true});checkWin(r);write();broadcastRoom(r.code);return res.json({room:sanitizeRoom(r,uid),maxNightsReached:true});}r.phase='Đêm';r.night++;r.day=r.night;}}else{if(r.phase==='Ngày'){r.phase='Đêm';r.night=Math.max(1,r.night-1);}else if(r.night>1){r.night--;r.phase='Ngày';r.day=Math.max(1,r.day-1);}}event(r,'Chuyển pha',`Chuyển sang ${phaseLabel(r)}.`,{public:true});checkWin(r);write();broadcastRoom(r.code);res.json({room:sanitizeRoom(r,uid)})});

app.post('/api/rooms/:code/action',(req,res)=>{const uid=requireAuth(req,res);if(!uid)return;const r=getRoom(req.params.code);if(!r)return res.status(404).json({error:'Không tìm thấy phòng.'});if(!r.started||r.ended)return res.status(400).json({error:'Ván chưa chạy hoặc đã kết thúc.'});const actor=getMember(r,uid);if(!actor||actor.userId===r.hostId)return res.status(403).json({error:'Quản trò không dùng API hành động người chơi.'});const target=req.body?.targetUserId?getMember(r,req.body.targetUserId):null;const type=String(req.body?.type||'Kỹ năng');if(target?.status==='Chết')return res.status(400).json({error:'Mục tiêu đã chết.'});const snap=actor.roleSnapshot||db.roles.find(x=>x.name===actor.role&&x.faction===actor.faction);if(!snap)return res.status(400).json({error:'Chức nghiệp chưa có luật kỹ năng.'});
  const usesKey=snap.id; if(actor.uses?.[usesKey]!==undefined && actor.uses[usesKey]<=0)return res.status(409).json({error:'Đã hết lượt sử dụng.'}); if(actor.uses?.[usesKey]!==undefined)actor.uses[usesKey]--;
  if(type==='Giết'&&target){target.status='Chết';target.cause=`${actor.name} — ${actor.role}`;event(r,'Người chơi bị giết',`${actor.name} tác động lên ${target.name}.`,{actorUserId:actor.userId,targetUserId:target.userId,public:true});}
  else if(type==='Hiệu ứng'&&target){const effectName=String(req.body?.effectName||snap.effect||snap.name);const turns=Math.max(1,Number(req.body?.turns||2));const e={id:id('fx'),name:effectName,sourceUserId:actor.userId,sourceRole:actor.role,targetUserId:target.userId,startPhase:phaseLabel(r),remaining:turns,status:'ACTIVE'};r.effects.push(e);target.effects.push(e.id);event(r,'Dính hiệu ứng',`${target.name} nhận ${effectName}.`,{actorUserId:actor.userId,targetUserId:target.userId,public:true});}
  else event(r,'Sử dụng kỹ năng',`${actor.name} — ${actor.role}${target?` → ${target.name}`:''}.`,{actorUserId:actor.userId,targetUserId:target?.userId||null,public:false});
  checkWin(r);write();broadcastRoom(r.code);res.json({room:sanitizeRoom(r,uid)})});

app.post('/api/rooms/:code/end',(req,res)=>{const uid=requireAuth(req,res);if(!uid)return;const r=getRoom(req.params.code);if(!r)return res.status(404).json({error:'Không tìm thấy phòng.'});if(r.hostId!==uid)return res.status(403).json({error:'Chỉ quản trò.'});const winner=String(req.body?.winner||'');if(!['Người','Quỷ','Độc lập','Hòa'].includes(winner))return res.status(400).json({error:'Phe thắng không hợp lệ.'});r.ended=true;r.winner=winner;event(r,'Kết thúc ván',winner==='Hòa'?'Ván kết thúc với kết quả hòa.':`Quản trò xác nhận phe ${winner} thắng.`,{public:true});write();broadcastRoom(r.code);res.json({room:sanitizeRoom(r,uid)})});
app.post('/api/rooms/:code/gm-event',(req,res)=>{const uid=requireAuth(req,res);if(!uid)return;const r=getRoom(req.params.code);if(!r)return res.status(404).json({error:'Không tìm thấy phòng.'});if(r.hostId!==uid)return res.status(403).json({error:'Chỉ quản trò.'});const target=req.body?.targetUserId?getMember(r,req.body.targetUserId):null;const type=String(req.body?.type||'Ghi chú');if((type==='Giết'||type==='Loại')&&target){target.status='Chết';target.cause=String(req.body?.cause||'Theo xử lý của quản trò');}event(r,type,String(req.body?.detail||''),{actorUserId:uid,targetUserId:target?.userId||null,public:true,cause:target?.cause||''});checkWin(r);write();broadcastRoom(r.code);res.json({room:sanitizeRoom(r,uid)})});

app.delete('/api/rooms/:code',(req,res)=>{const uid=requireAuth(req,res);if(!uid)return;const r=getRoom(req.params.code);if(!r)return res.status(404).json({error:'Không tìm thấy phòng.'});if(r.hostId!==uid)return res.status(403).json({error:'Chỉ quản trò.'});delete db.rooms[r.code];write();for(const ws of sockets.get(r.code)||[])if(ws.readyState===1)ws.close(1000,'room deleted');sockets.delete(r.code);res.json({ok:true})});

wss.on('connection',(ws,req)=>{
  const u=new URL(req.url,'http://localhost'); const t=u.searchParams.get('token');const roomCode=u.searchParams.get('room')?.toUpperCase();const s=sessions.get(t);if(!s||s.expires<Date.now()){ws.close(1008,'unauthorized');return}const room=getRoom(roomCode);if(!room||!getMember(room,s.userId)){ws.close(1008,'room');return}ws.userId=s.userId;ws.roomCode=roomCode;if(!sockets.has(roomCode))sockets.set(roomCode,new Set());sockets.get(roomCode).add(ws);ws.send(JSON.stringify({type:'room_state',data:sanitizeRoom(room,s.userId)}));ws.on('close',()=>sockets.get(roomCode)?.delete(ws));
});

app.use(express.static(path.join(__dirname,'public')));
app.get('/{*splat}',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
http.listen(PORT,'0.0.0.0',()=>console.log(`The Omen Online v0.9 on ${PORT}`));
